var janela = document.getElementById("janela");


function abrirJanela(){
	janela.src = "img/1.jpg";
}

function fecharJanela(){
	janela.src = "img/2.jpg";
}

function quebrarJanela(){
	janela.src = "img/3.jpg";
}