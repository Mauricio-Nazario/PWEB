var sql = require ('mssql/msnodesqlv8'); 
module.exports = function(){ 
 
 const config = { 
 user: 'BD2013020', 
 password: 'Mau704101', 
 database: '192.168.1.6', //your database 
 server: 'BD', 
 driver: 'msnodesqlv8', 
 } 
 return sql.connect(config); 
} 